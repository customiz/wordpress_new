<div class="updated as3cf-notice">
	<p><?php echo $message; // xss ok ?></p>
</div>
