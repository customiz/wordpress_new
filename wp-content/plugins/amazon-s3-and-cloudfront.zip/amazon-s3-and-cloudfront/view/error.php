<div class="error">
	<p><?php echo $message; // xss ok ?></p>
</div>
